# Cash Register

[Cash Register](https://kk-kuldeep.github.io/cash_register/) as the name suggests is a web app that can be used to calculate cash related info & potentailly store it as well for future references.

_Although this is a very simple implementation of cash register which just gives us the minimum number of notes sorted in decreasing order of denomination._

![demo-img](./assets/images/demos/demo1.png)
